import streamlit as st
import requests

def call_imagen(lat,lng,zoom,ancho,alto):
    try:
        url = "http://localhost:8000"
        dicc = {"lat":lat,
                "lng":lng,
                "zoom":zoom,
                "ancho":ancho,
                "alto":alto
                }
        response = requests.post(f"{url}/load_mapics", params=dicc)
        response.raise_for_status()
        data = response.json()
        return data
    except requests.RequestException as e:
        st.error(f"error: {e}")
        return None
