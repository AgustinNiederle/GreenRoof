import streamlit as st
import requests
import pandas as pd

API_KEY = "AIzaSyDDt1fiH2cTopWMX_qfg50nm0taKg4egV4"
EARTH_CIRCUMFERENCE = 40075017

def download_google_maps_image(lat, lon, zoom=17, size="640x640"):
    base_url = "https://maps.googleapis.com/maps/api/staticmap?"
    params = {
        "center": f"{lat},{lon}",
        "zoom": zoom,
        "size": size,
        "key": API_KEY,
        "maptype": "satellite"
    }
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        return response.content
    else:
        st.error("No se pudo descargar la imagen de Google Maps.")
        return None

def main():
    st.title("Optimización de Techos y Huertas")
    latitude = st.number_input("Latitud", format="%.6f")
    longitude = st.number_input("Longitud", format="%.6f")
    zoom = st.slider("Zoom del mapa (17-20)", min_value=17, max_value=20, value=19)
    confidence_threshold = st.slider("Umbral de Confianza", min_value=0.0, max_value=1.0, value=0.5, step=0.05)

    if st.button("Analizar"):
        map_image = download_google_maps_image(latitude, longitude, zoom)
        if map_image:
            with open("temp_image.png", "wb") as f:
                f.write(map_image)

            files = {'file': open("temp_image.png", 'rb')}
            response = requests.post(
                "http://127.0.0.1:8000/analyze_image/",
                files=files,
                data={'confidence_threshold': confidence_threshold, 'zoom': zoom}
            )

            if response.status_code == 200:
                yolo_results = response.json()
                if yolo_results:
                    df_results = pd.DataFrame(yolo_results)
                    st.image(map_image, caption="Imagen de Google Maps")
                    st.write("Resultados:")
                    st.dataframe(df_results)
                else:
                    st.write("No se detectaron techos.")
            else:
                st.write("Error en el análisis de la imagen.")

if __name__ == "__main__":
    main()