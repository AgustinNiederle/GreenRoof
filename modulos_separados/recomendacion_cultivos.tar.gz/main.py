from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
import cv2
import numpy as np
import pandas as pd
from ultralytics import YOLO

API_KEY = "AIzaSyDDt1fiH2cTopWMX_qfg50nm0taKg4egV4"
EARTH_CIRCUMFERENCE = 40075017

model = YOLO('https://hub.ultralytics.com/models/Czs374EmaPayXhi5qN5z')

app = FastAPI()

def calculate_scale(zoom, image_width):
    return EARTH_CIRCUMFERENCE / (2**zoom * image_width)

@app.post("/analyze_image/")
async def analyze_image(file: UploadFile = File(...), confidence_threshold: float = 0.5, zoom: int = 19):
    contents = await file.read()
    np_img = np.frombuffer(contents, np.uint8)
    image = cv2.imdecode(np_img, cv2.IMREAD_COLOR)
    
    scale = calculate_scale(zoom, image.shape[1])
    results = model(image, conf=confidence_threshold)
    boxes = results[0].boxes
    class_names = model.names

    if boxes is not None:
        detections = boxes.xyxy.numpy()
        confidences = boxes.conf.numpy()
        classes = boxes.cls.numpy()

        areas = []
        labels = []
        coords = []

        for i, (box, conf, cls_id) in enumerate(zip(detections, confidences, classes)):
            class_name = class_names[int(cls_id)]

            if class_name == "roof":
                width = (box[2] - box[0]) * scale
                height = (box[3] - box[1]) * scale
                area = width * height
                areas.append(area)
                coords.append(box.tolist())
                label = f"Techo {len(labels) + 1}"
                labels.append(label)

        if labels:
            df_results = pd.DataFrame({
                "label": labels,
                "x1": [c[0] for c in coords],
                "y1": [c[1] for c in coords],
                "x2": [c[2] for c in coords],
                "y2": [c[3] for c in coords],
                "area_m2": areas
            })
            return JSONResponse(content=df_results.to_dict(orient="records"))
    return JSONResponse(content=[])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)