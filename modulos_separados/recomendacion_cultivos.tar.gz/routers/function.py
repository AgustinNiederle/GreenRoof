from fastapi import APIRouter

saludo = APIRouter()
@saludo.post("/saludo")
def saludar (nombre):
    texto_saludo = f"hola {nombre}"
    return texto_saludo